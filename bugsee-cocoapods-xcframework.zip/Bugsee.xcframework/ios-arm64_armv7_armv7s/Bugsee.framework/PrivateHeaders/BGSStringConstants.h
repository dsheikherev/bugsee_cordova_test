#import <Foundation/Foundation.h> 

OBJC_EXPORT NSString *  bgs_focusJSInjectString(void);
OBJC_EXPORT NSString *  bgs_ajaxJSInjectString(void);
OBJC_EXPORT NSString *  bgs_shaderMetalInjectString(void);
